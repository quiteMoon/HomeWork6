from tkinter import *

def Red():
    label.config(text = "Red")
    entry.delete(0, END)
    entry.insert(0, "#ff050d")
    root["background"] = "#ff050d"

def Blue():
    label.config(text = "Blue")
    entry.delete(0, END)
    entry.insert(0, "#0000FF")
    root["background"] = "#0000FF"

def Green():
    label.config(text = "Green")
    entry.delete(0, END)
    entry.insert(0, "#008000")
    root["background"] = "#008000"

def Thistle():
    label.config(text = "Thistle")
    entry.delete(0, END)
    entry.insert(0, "#D8BFD8")
    root["background"] = "#D8BFD8"

def Teal():
    label.config(text = "Teal")
    entry.delete(0, END)
    entry.insert(0, "#008080")
    root["background"] = "#008080"

def Tan():
    label.config(text = "Tan")
    entry.delete(0, END)
    entry.insert(0, "#D2B48C")
    root["background"] = "#D2B48C"

def SkyBlue():
    label.config(text = "SkyBlue")
    entry.delete(0, END)
    entry.insert(0, "#87CEEB")
    root["background"] = "#87CEEB"

def Olive():
    label.config(text = "Olive")
    entry.delete(0, END)
    entry.insert(0, "#808000")
    root["background"] = "#808000"

def MediumAquamarine():
    label.config(text = "MediumAquamarine")
    entry.delete(0, END)
    entry.insert(0, "#66CDAA")
    root["background"] = "#66CDAA"

def DarkGray():
    label.config(text = "DarkGray")
    entry.delete(0, END)
    entry.insert(0, "#A9A9A9")
    root["background"] = "#A9A9A9"

def makeButton(color, function):
    button = Button(root, text=color, width=16, bg=color, fg="white", command=function)
    button.pack()

root = Tk()
root.title("Color Picker")
root.geometry("180x360")

label = Label(root, anchor="c")
label.pack()

entry = Entry(root, justify="center", bd=5)
entry.pack()

makeButton("Red", Red)
makeButton("Blue", Blue)
makeButton("Green", Green)
makeButton("Thistle", Thistle)
makeButton("Teal", Teal)
makeButton("Tan", Tan)
makeButton("SkyBlue", SkyBlue)
makeButton("Olive", Olive)
makeButton("MediumAquamarine", MediumAquamarine)
makeButton("DarkGray", DarkGray)

root.mainloop()