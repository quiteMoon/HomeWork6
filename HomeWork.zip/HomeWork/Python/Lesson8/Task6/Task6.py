def replace_word_in_file(filename, search_word, new_word):
  with open(filename, "r", encoding="utf-8") as f:
    text = f.read()
    new_text = text.replace(search_word, new_word)
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write(new_text)
        print(f"Слово '{search_word}' успішно замінено на '{new_word}' в файлі '{filename}'.\n")
        print(new_text)



filename = "file1"
with open(filename, "r", encoding="utf-8") as f:
    text = f.read()
    print(text)
search_word = input("\nВведіть слово яке потрібно замінити: ")
new_word = input('\nВведіть слово на яке потрібно змінити: ')

replace_word_in_file(filename, search_word, new_word)
