def count_stats(filename):
    with open(filename, "r") as f:
        text = f.read()
    
        characters = len(text)

        lines = text.count("\n") + 1
    
        vowels = 0
        for char in text.lower():
            if char in "аеиоуієюяї":
                vowels += 1

        consonants = 0
        for char in text.lower():
            if char in "бвгджзклмнпрстфхцчшщь":
                consonants += 1

        digits = 0
        for char in text:
            if char.isdigit():
                digits += 1

    return {
          "characters": characters,
          "lines": lines,
          "vowels": vowels,
          "consonants": consonants,
          "digits": digits,
        }

filename = "file1"
stats = count_stats(filename)

# Запис статистики до нового файлу
with open("stats.txt", "w") as f:
  for key, value in stats.items():
    f.write(f"{key}: {value}\n")


print(f"Статистика успішно записана до файлу stats.txt")