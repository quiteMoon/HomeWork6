def find_longest_line(filename):
  longest_line = 0
  with open(filename, "r", encoding='utf-8') as f:
    for line in f:
      line_length = len(line)
      if line_length > longest_line:
        longest_line = line_length
  return longest_line

filename = "file1"
longest_line_length = find_longest_line(filename)
print(f"Довжина найдовшого рядка: {longest_line_length}")