file1 = "file1"
file2 = "file2"

with open(file1, 'r', encoding='utf-8') as file:
    lines = file.readlines()

if lines:
    lines.pop()

with open(file2, 'w', encoding='utf-8') as file:
    file.writelines(lines)


