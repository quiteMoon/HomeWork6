def count_words(filename, word):
  with open(filename, "r", encoding='utf-8') as f:
    text = f.read().lower()
    words = text.split()
    count = 0
    for w in words:
      if w == word:
        count += 1
  return count

filename = "file1"
with open(filename, "r", encoding='utf-8') as f:
    text = f.read()
    print(text)
word = input("\nВведіть слово яке хочете порахувати в тексті: ")
count = count_words(filename, word)
print(f"Кількість слова '{word}' у файлі '{filename}': {count}")