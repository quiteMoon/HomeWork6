def compare_files(file1, file2):
  with open(file1, "r") as f1, open(file2, "r") as f2:
    lines1 = f1.readlines()
    lines2 = f2.readlines()
  
  if len(lines1) != len(lines2):
    print("Файли мають різну довжину.")
    return []

  mismatches = []
  for i, line1 in enumerate(lines1):
    line2 = lines2[i]
    if line1 != line2:
      mismatches.append((i + 1, line1.strip(), line2.strip()))

  return mismatches

file1 = "file1"
file2 = "file2"

mismatches = compare_files(file1, file2)

if mismatches:
  print("Рядки, які не співпадають:")
  for i, line1, line2 in mismatches:
    print(f"Рядок {i}:")
    print(f"  Файл {file1}: {line1}")
    print(f"  Файл {file2}: {line2}")
else:
  print("Файли співпадають.")